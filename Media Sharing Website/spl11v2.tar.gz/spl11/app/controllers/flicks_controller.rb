class FlicksController < ApplicationController
  before_action :set_flick, only: [:show, :edit, :update, :destroy]

  # GET /flicks
  # GET /flicks.json
  def index
    #get a list of all items in dynamo db
    @flicks = nil
    begin
      dynamodb = Aws::DynamoDB::Client.new
      data = dynamodb.scan({:table_name => CREDS["table_name"]})
      @flicks = data.items
    rescue Exception => e
      render "index", :alert => e.message
    end
  end

  # GET /flicks/1
  # GET /flicks/1.json
  def show
  end

  # GET /flicks/new
  def new
    @flick = Flick.new
  end

  # GET /flicks/1/edit
  def edit
  end

  # POST /flicks
  # POST /flicks.json
  def create
    @flick = Flick.new(flick_params)

    respond_to do |format|
      if @flick.save
        format.html { redirect_to flicks_url, notice: 'Flick was successfully created.' }
        format.json { render :show, status: :created, location: @flick }
      else
        format.html { redirect_to :back, alert: @flick.errors}
        format.json { render json: @flick.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /flicks/1
  # PATCH/PUT /flicks/1.json
  def update
    respond_to do |format|
      if @flick.update(flick_params)
        format.html { redirect_to @flick, notice: 'Flick was successfully updated.' }
        format.json { render :show, status: :ok, location: @flick }
      else
        format.html { render :edit }
        format.json { render json: @flick.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /flicks/1
  # DELETE /flicks/1.json
  def destroy
    @flick.destroy
    respond_to do |format|
      format.html { redirect_to flicks_url, notice: 'Flick was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_flick
      @flick = Flick.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def flick_params
      params.require(:flick).permit(:uuid_string, :title, :description, :tags, :image_file)
    end
end
