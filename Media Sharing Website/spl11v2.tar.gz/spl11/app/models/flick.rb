require 'RMagick'
class Flick < ActiveRecord::Base
  attr_accessor :title
  attr_accessor :description
  attr_accessor :tags
  attr_accessor :image_file

  #validates_format_of :image_file, :with => %r{\.(gif|jpg|jpeg|png|JPG)\z}i, :message => 'image format must be GIF, JPG ' + 'or PNG image.'

  before_save :s3_dynamodb

  def s3_dynamodb
    begin
      #get all details of file
      file = self.image_file
      extname = File.extname file.original_filename
      content_type = file.content_type
      file_contents = file.read
      img = Magick::Image.from_blob(file_contents).first
      thumbnail = img.thumbnail(img.columns*0.09, img.rows*0.09)
      guid = SecureRandom.uuid
      s3 = Aws::S3::Resource.new
      bucket = s3.bucket(CREDS["bucket_name"])
      options = Hash.new
      options[:key] = guid + extname
      options[:content_type] = content_type
      options[:body] = file_contents

      t_options = Hash.new
      t_options[:key] = guid + "tn"+ extname
      t_options[:content_type] = content_type
      t_options[:body] = thumbnail.to_blob

      object = bucket.put_object options
      t_object = bucket.put_object t_options
      item = {
        :eib => guid,
        :title => self.title,
        :description => self.description,
        :tags => self.tags,
        :image => object.public_url,
        :t_image => t_object.public_url
      }

      dynamodb = Aws::DynamoDB::Client.new
      dynamodb.put_item(:table_name => CREDS["table_name"], :item => item)
      true
    rescue Exception => e
      errors.add(:base, "ERROR: either storing to S3 of inserting to DynamoDB #{e.message}")
      false
    end
  end

end
