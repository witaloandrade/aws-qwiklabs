CREDS = YAML.load_file "tmp/creds.yml"
Aws.config.update({
  region: CREDS["region"]
})
