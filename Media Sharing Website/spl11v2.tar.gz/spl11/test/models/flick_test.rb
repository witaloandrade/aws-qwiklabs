require 'test_helper'

class FlickTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
