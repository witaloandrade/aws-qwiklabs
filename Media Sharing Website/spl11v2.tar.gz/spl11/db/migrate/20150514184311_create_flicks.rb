class CreateFlicks < ActiveRecord::Migration
  def change
    create_table :flicks do |t|
      t.string :uuid_string

      t.timestamps null: false
    end
  end
end
